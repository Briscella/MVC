<?php
include 'model_pasien.php';
$isiTabelPasien = getTabelPasien();
include 'view_pasien.php';