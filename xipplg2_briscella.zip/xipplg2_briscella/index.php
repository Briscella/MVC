<?php
header('location: controller_pasien.php');