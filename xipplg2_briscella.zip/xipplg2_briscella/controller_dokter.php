<?php
include 'model_dokter.php';
$isiTabelDokter = getTabelDokter();
include 'view_dokter.php';