<?php
include 'model_pasien.php';
$isiTabelKunjungan = getTabelKunjungan();
include 'view_pasien.php';